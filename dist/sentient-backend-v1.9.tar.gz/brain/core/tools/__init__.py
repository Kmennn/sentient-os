# Init
from core.tools.registry import registry
from core.tools.defaults import register_defaults

# Auto-register defaults on import
register_defaults()
